#!/bin/bash

python3 src/TournamentStreamHelper.pyw